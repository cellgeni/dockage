# -*- coding: utf-8 -*-
"""
-----------------------------------------------------------------------------
  Copyright (C) 2020 Glencoe Software, Inc. All rights reserved.

  This software is distributed under the terms described by the LICENCE file
  you can find at the root of the distribution bundle.
  If the file is missing please request a copy by contacting
  support@glencoesoftware.com.

------------------------------------------------------------------------------
"""
import logging
import sys
# Namespace package, see
# https://stackoverflow.com/questions/1675734/
#     how-do-i-create-a-namespace-package-in-python
from pkgutil import extend_path


__path__ = extend_path(__path__, __name__)

LOGGING_FORMAT = "%(asctime)s %(levelname)-7s [%(name)16s] %(message)s"
logging.basicConfig(
    level=logging.INFO, format=LOGGING_FORMAT, stream=sys.stdout)
