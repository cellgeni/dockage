import zarr
import cv2
import os
import numpy as np
import logging
import sys

LOGGING_FORMAT = "%(asctime)s %(levelname)-7s [%(name)16s] %(message)s"
LOGGER = logging.getLogger('gs_scripts.make_zarr')
logging.basicConfig(
    level=logging.INFO, format=LOGGING_FORMAT, stream=sys.stdout)


def makezarr(
        directory, imageId, image, label, metadata,
        UUID, shape, data_type, series='0', overwrite=False, debug=False):
    '''
    generate a new zarr file with both image and label data
    both image and/or label can =True, and use shape and data_type to define
    your tiledb
    '''
    # base resolution is called 0
    base = '0'
    directory = os.path.join(directory, str(imageId) + '.zarr')
    store = zarr.storage.FSStore(
        directory, auto_mkdir=True,
        dimension_separator="/", normalize_keys=False)

    # make directory-level zarr group and add group-level metadata
    root = zarr.group(store=store, overwrite=False)
    group = None
    if series in root:
        group = root[series]
    else:
        group = root.create_group(series)
    if image:
        raise Exception('not implemented.')
    if label:
        if 'labels' in group:
            group = group['labels']
        else:
            group = group.create_group('labels')
        if UUID in group:
            if not overwrite:
                raise ValueError(f"Zarr group {UUID} already exists. "
                                 f"Use --overwrite if you want to replace it.")
            else:
                LOGGER.warning(f"Overwriting existing group {UUID}")
            group = group.create_group(UUID, overwrite=True)
        else:
            group = group.create_group(UUID)
        array_directory = os.path.join(directory, series, 'labels', UUID)
        scale = makezarr_array(
            array_directory, base=base, downscale=2, label=True,
            shape=shape, data_type=data_type)
        labels_group = os.path.join(directory, series, 'labels')
        group = zarr.open_group(labels_group)
        if 'labels' in group.attrs:
            UUIDs = group.attrs['labels']
            UUIDs.append(UUID)
            group.attrs['labels'] = UUIDs
        else:
            group.attrs['labels'] = [UUID]
        LOGGER.debug("Labels metadata: {}".format(group.attrs['labels']))

    return array_directory, base, scale


def makezarr_array(
        array_directory, base='0', downscale=None,
        label=False, shape=None, data_type=None):
    # group = zarr.open_group(array_directory)
    store = zarr.storage.FSStore(
        array_directory, auto_mkdir=True,
        dimension_separator="/", normalize_keys=False)
    group = zarr.group(store=store, overwrite=True)
    if base in group:
        LOGGER.warning('Arrays already exist and will be overwritten.')
    else:
        LOGGER.info('Array write to %s' % array_directory)

    group.create(
            name=base,
            dtype=data_type,
            shape=shape,
            chunks=(1, 1, 1, 512, 512),
            compression='zlib',
            overwrite=True,
            dimension_separator='/'
        )
    LOGGER.debug("Created array at resolution level %s" % str(base))
    metadata = {
        "datasets": [{"path": base}],
        "version": "0.2"}

    if downscale is not None:
        base = 1
        while shape[3] > 256 or shape[4] > 256:
            shape = (
                shape[0], shape[1], shape[2],
                shape[3] // downscale, shape[4] // downscale)
            group.create(
                name=str(base),
                dtype=data_type,
                shape=shape,
                chunks=(1, 1, 1, 512, 512),
                compression='zlib',
                overwrite=True,
                dimension_separator='/'
            )
            LOGGER.debug("Created array at resolution level %s" % str(base))
            metadata['datasets'].append({'path': str(base)})
            base += 1
    group.attrs['multiscales'] = [metadata]

    return base


def scale(plane, downscale):
    '''
    scale arrays for multiresolutions, a very simplified local
    implementation compared to scale.py from ome-zarr
    '''
    sizeY = plane.shape[0]
    sizeX = plane.shape[1]
    if plane.dtype == 'uint32':
        plane = plane.astype(np.float32)
    scaled = cv2.resize(plane,
                        dsize=(sizeX // downscale, sizeY // downscale),
                        interpolation=cv2.INTER_NEAREST)
    return scaled.astype(np.uint32)


def writezarr(
        array, x, y, width, height, directory,
        scaling=True, resolution_levels=0, sync=None):
    path = os.path.join(directory)
    if not scaling:
        store = zarr.storage.FSStore(path, auto_mkdir=True, mode='w',
                                     dimension_separator='/')
        A = zarr.open_array(store=store, synchronizer=sync)
        array = np.where(array == 0,
                         A[0, 0, 0, y:(y + height), x:(x + width)], array)
        A[0, 0, 0, y:(y + height), x:(x + width)] = array
        return
    for res in range(resolution_levels):
        factor = 2
        if res == 0:
            path = os.path.join(directory, str(res))
            store = zarr.storage.FSStore(
                path, auto_mkdir=True, mode='w',
                dimension_separator='/', synchronizer=sync)
            A = zarr.open_array(store=store)
            array = np.where(
                array == 0,
                A[0, 0, 0, y:(y + height), x:(x + width)],
                array)
            A[0, 0, 0, y:(y + height), x:(x + width)] = array
        else:
            path = os.path.join(directory, str(res))
            x = x // factor
            y = y // factor
            width = width // factor
            height = height // factor
            if width > 0 and height > 0:
                array = scale(array, factor)
                store = zarr.storage.FSStore(
                    path, auto_mkdir=True, mode='w',
                    dimension_separator='/', synchronizer=sync)
                A = zarr.open_array(store=store)
                array = np.where(
                    array == 0,
                    A[0, 0, 0, y:(y + height), x:(x + width)],
                    array)
                A[0, 0, 0, y:(y + height), x:(x + width)] = array


def label_attributes(zarr_group, max_object, min_object=0):
    zarr_group.attrs['minmax'] = [min_object, max_object]
    zarr_group.attrs['image-label'] = {
        "version": "0.2"
    }
