import tempfile
import time
import multiprocessing as mp
from shapely import wkt
from shapely.geometry import Polygon, Point
from shapely.affinity import translate, scale, affine_transform
import argparse
from ROI_Converter_NGFF.make_zarr import makezarr, writezarr, label_attributes
from omero_metadata.populate import ParsingContext
from omero_metadata.cli import MetadataControl
import numpy as np
from rasterio import features
import json
import uuid
import math
import os
import posixpath
import logging
import sys
import omero
from omero.gateway import BlitzGateway, ColorHolder
from omero.rtypes import rstring, rlong, rdouble, rint
import zarr
import pandas as pd
import geopandas
import csv
import cv2
import sqlite3
from sqlalchemy import create_engine

SCHEMA = "http://www.openmicroscopy.org/Schemas/OME/2016-06"
AFFINE_MATRIX = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
INDEX_COLUMN = 'object'
BBOX_MIN_X = "bbox_min_x"
BBOX_MIN_Y = "bbox_min_y"
BBOX_MAX_X = "bbox_max_x"
BBOX_MAX_Y = "bbox_max_y"
BOUNDS_LABELS = [BBOX_MIN_X, BBOX_MIN_Y, BBOX_MAX_X, BBOX_MAX_Y]

LOGGING_FORMAT = "%(asctime)s %(levelname)-7s [%(name)16s] %(message)s"
LOGGER = logging.getLogger('gs_scripts.raster')
logging.basicConfig(
    level=logging.INFO, format=LOGGING_FORMAT, stream=sys.stdout)


def parse_arguments():
    description = '''
    Convert WKT, CSV and OME-XML to OME-NGFF.
    OME-NGFF image can be converted to OME-NGFF label image in-place.
    '''
    width = 500
    column_width = 500
    parser = argparse.ArgumentParser(
        prog='ROI_Converter_NGFF',
        description=description,
        formatter_class=lambda
        prog: argparse.HelpFormatter(
            prog, max_help_position=column_width, width=width
        )
    )
    parser.add_argument(
        '-i', '--input_file', '--input-file', required=True,
        help='''
        input WKT, CSV, OME-XML or OME-NGFF file
        CSV input requies "polygon" column with geometry
        (unless using --column_name) and "object" column with object IDs
        '''
    )
    parser.add_argument(
        '-d', '--directory', required=False,
        help='output directory'
    )
    parser.add_argument(
        '-f', '--output_filename', '--output-filename', required=False,
        help='''
        output file name without extension,
        default output is <input_file>.zarr
        '''
    )
    parser.add_argument(
        '-W', '--width', required=False,
        help=('input image width, required for OME-XML, WKT & CSV ' +
              'conversion, unless used with --register_to'),
        type=int
    )
    parser.add_argument(
        '-H', '--height', required=False,
        help=('input image height, required for OME-XML, WKT & CSV ' +
              'conversion, unless used with --register_to'),
        type=int
    )
    parser.add_argument(
        '-t', '--tile_size', '--tile-size', required=False,
        default=2048,
        help='''
        tile size for writing OME-XML, WKT and CSV conversion,
        larger tiles will be faster but use more memory
        ''',
        type=int
    )
    parser.add_argument(
        '--no_fill', '--no-fill', action='store_true',
        help='only rasterize polygon borders', default=False
    )
    parser.add_argument(
        '-r', '--register_to', '--register-to', required=False, type=int,
        help='create OMERO label image and register unique identifier.'
    )
    parser.add_argument(
        '--server', required=False, default=None,
        help='OMERO server address if registering the ROIs to a server. '
             'Required if connecting using the --key or --user arguments.'
             'If not provided and no other server details are specified, '
             'the omero_user_token package will be checked '
             'for a valid token instead.'
    )
    parser.add_argument(
        '--port', required=False, default=4064, type=int,
        help='OMERO server port used if registering the ROIs to a server.'
    )
    parser.add_argument(
        '--user', required=False, default=None,
        help='OMERO username for login if registering the ROIs to a server.'
    )
    parser.add_argument(
        '--password', required=False, default=None,
        help='Password for the OMERO server to be sent with --user. '
    )
    parser.add_argument(
        '--key', required=False, default=None,
        help='OMERO session key used if registering the ROIs to a server. '
             'Can be used to connect to a server instead of providing a '
             'username and password.'
    )
    parser.add_argument(
        '-s', '--series', required=False, default='0',
        help='OME-NGFF series to write, <name>.zarr/<series>'
    )
    parser.add_argument(
        '-l', '--label', required=False, default=None,
        help='Name for the labels group within the OME-NGFF series. By default'
             ' a random ID is generated. If the label name already exists '
             'the --overwrite flag can be provided to replace it.'
    )
    parser.add_argument(
        '-o', '--overwrite', required=False, action='store_true',
        help='Overwrite existing label groups'
    )
    parser.add_argument(
        '--table', required=False, action='store_true',
        help='Populate an OMERO table with CSV input. Must include -r.'
    )
    parser.add_argument(
        '-n', '--name', required=False, default='ROI_Converter_NGFF',
        help='Name for registered ROI in OMERO'
    )
    parser.add_argument(
        '-c', '--column_name', '--column-name', required=False,
        default='polygon', help='Name for geometry column in CSV input'
    )
    parser.add_argument(
        '--downsample_type', '--downsample-type', required=False,
        default='vector', choices=['vector', 'raster'],
        help='''
            Method for downsampling.
            Vector is better for small geometries,
            but takes more time.
            '''
    )
    parser.add_argument(
        '--num_objects', '--num-objects', required=False, default=None,
        help='Number of objects in input. Best practice for OME-NGFF input.'
    )
    parser.add_argument(
        '--no_clean', '--no-clean', required=False, action='store_true',
        help='''
        Used for OME-NGFF in-place conversion. Keeps original OME-NGFF image.
        '''
    )
    parser.add_argument(
        '--max_procs', '--max-procs', required=False, default=1, type=int,
        help='max workers to use for rastering'
    )
    parser.add_argument(
        '-m', '--mode', required=False, default='local',
        choices=['sqlite', 'postgres', 'local'],
        help='Method for handling polygon data.'
    )
    parser.add_argument(
        '--db', required=False,
        default="postgresql://user:@localhost/table",
        help="Connection details for postgres. "
             "Format 'postgresql://user:@localhost/table'"
    )
    parser.add_argument(
        '--debug', required=False, action='store_true',
        help='Set logging level to DEBUG'
    )
    parser.add_argument(
        '--server_directory', '--server-directory', required=False,
        default=None,
        help='Output directory within the OMERO.server environment. '
        'Use in case the workstation path is different than '
        'the server path (e.g. /mnt/label_images/ vs /drive/label_images/). '
        'Overwrites registered path.', type=check_abspath_server_dir
    )
    parser.add_argument(
        '--disable_table_statistics', '--disable-table-statistics',
        required=False, action='store_true',
        help='Disables table statistics generation in the metadata properties '
        'for the table (min, max, mean, median, skew, kurtosis, '
        'standard deviation, and histogram information).'
    )
    parser.add_argument(
        '--table_name', '--table-name', required=False,
        help='Name for registered OMERO.table in OMERO'
    )
    parser.set_defaults(func=director)
    args = parser.parse_args()
    args.func(vars(args))


def director(args):
    """
    Main function that contains processing, conversion, creation and
    registration of label images
    """
    start = time.perf_counter()
    if args['debug']:
        LOGGER.setLevel(logging.DEBUG)
    input_file = args['input_file']
    dirname = os.path.dirname(input_file)
    filename = os.path.basename(input_file)
    filename, file_extension = os.path.splitext(filename)
    if file_extension == '':
        directory = os.path.dirname(input_file.rstrip('/'))
        if os.path.splitext(directory)[1] == '.zarr':
            file_extension = '.zarr'
        elif os.path.isfile(os.path.join(directory, '.zgroup')):
            file_extension = '.zarr'
        else:
            LOGGER.error('File type not supported.')
            return
    file_extension = file_extension.lower()
    if args['output_filename'] is None:
        args['output_filename'] = filename
    if args['directory'] is None:
        args['directory'] = dirname
    if args['table'] and not args['register_to']:
        LOGGER.error('Cannot add table without -r option input')
        args['table'] = False
    if args['table_name'] is None:
        args['table_name'] = 'ROI_Converter_NGFF'
    client = None
    gateway = None
    try:
        if args['register_to'] is not None:
            # check for token before conversion if registering in OMERO
            client, server, session_key = get_omero_client(args)
            gateway = BlitzGateway(client_obj=client)
            user = gateway.getUser()
            # reset output image name to Fileset ID
            image_id = args['register_to']
            try:
                gateway.SERVICE_OPTS.setOmeroGroup('-1')
                img = gateway.getObject("Image", image_id)
                if args['width'] or args['height']:
                    LOGGER.warning("Ignoring width and height arguments. "
                                   "Using width and height from OMERO image.")
                args['width'] = img.getSizeX()
                args['height'] = img.getSizeY()
                LOGGER.debug(
                    f"Image found. Using width:{args['width']} and "
                    f"height:{args['height']} from image.")
                group = img.getDetails().getGroup()
                group_id = group.getId()
                group_name = group.getName()
                gateway.SERVICE_OPTS.setOmeroGroup(group_id)
                LOGGER.info(
                    "OMERO user id: %s, username: %s, full name: %s, "
                    "group: %s" % (
                        user.getId(), user.getName(),
                        user.getFullName(), group_name)
                )
                fileset = img.getFileset()
                fileset_id = fileset.getId()
                series = img.getSeries()
                if args['output_filename'] != str(fileset_id):
                    LOGGER.warning(
                        'Changing output filename to be %s' % (fileset_id))
                    args['output_filename'] = str(fileset_id)
                if str(args['series']) != str(series):
                    LOGGER.warning(
                        'Changing series to %s' % (series))
                    args['series'] = str(series)
            except Exception:
                LOGGER.warning(
                    'Could not find image with given ID in your groups.')
                LOGGER.warning('Resetting --register_to to None')
                if args['table']:
                    LOGGER.warning('Not adding OMERO.table')
                    args['table'] = False
                args['register_to'] = None
        if args['register_to'] is not None and \
                args['server_directory'] is None:
            if check_running_on_windows():
                LOGGER.error('Must specify --server_directory option ' +
                             'when using -r option from Windows')
                return
        if file_extension in ['.wkt', '.csv', '.xml']:
            if not args['register_to'] and \
                    (not args['height'] or not args['width']):
                raise Exception(
                    'Height and width necessary for conversion.')
            uuid_paths, shape_lists, extra_cols = parse_file(args, input_file,
                                                             file_extension)
        elif file_extension in ('.tiff', '.tif'):
            raise Exception(
                'TIFF input no longer supported. See README for details.')
        elif file_extension == ".zarr":
            uuid_path = convert_ngff(args)
            if not uuid_path:
                return
            uuid_paths = [uuid_path]
        else:
            LOGGER.error('File type not supported.')
            return
        if not uuid_paths:
            return
        if args['register_to'] is not None:
            LOGGER.info('Conversion complete. Beginning OMERO registration.')
            rois, roi_name, roi_id = register(
                gateway, image_id, uuid_paths, args)
            LOGGER.info("Saved %i ROIs" % len(rois))
        else:
            LOGGER.info('Conversion complete.')
        if args['register_to'] is not None and args['table']:
            if file_extension == '.csv':
                collection = geopandas.GeoDataFrame(
                    data=extra_cols,
                    index=extra_cols.index if
                    extra_cols is not None else None,
                    geometry=[shape for shape_list in shape_lists
                              for shape in shape_list])
                collection['roi'] = roi_id
                # Use geometry bounds if we don't have a bbox_* column
                if any([column in collection.columns
                        for column in BOUNDS_LABELS]):
                    LOGGER.warning("Skipping bounding box column creation "
                                   "since one or more bbox_* columns are "
                                   "present in the input file.")
                else:
                    collection[BOUNDS_LABELS] = collection.geometry.bounds
                path = os.path.join(
                    args['directory'],
                    args['output_filename'] + '.zarr',
                    'out.csv')
                collection.to_csv(path, mode='w')

                table_id = upload_table(
                    client, args['register_to'], path, args['table_name'])
                link_table_to_roi(gateway, table_id, roi_id)
                if not args['disable_table_statistics']:
                    compute_table_statistics(gateway, table_id)

            else:
                LOGGER.error('Table registration only supported for CSV '
                             'inputs.')
        LOGGER.info(f'Finished in {time.perf_counter() - start}.')
        return True
    finally:
        if gateway is not None:
            gateway.close(hard=False)
        if client is not None:
            client.closeSession()


def upload_table(client, id, path, table_name):
    '''
    Method that uses omero-metadata function to parse and upload omero tables
    to target image and automatically detects header type.

    :param client: An instance of an omero.client object
    :param id: ID of the target image as string
    :param path: Path to the CSV file as string

    :return: ID of the table in OMERO as int

    :raises FileNotFoundError: If the specified CSV file is not found
    :raises Exception: If there are issues related to the OMERO connection
    '''
    try:
        LOGGER.debug('Uploading Omero Metadata Table')
        LOGGER.debug(f"Uploading '{table_name}'")
        omero_object = omero.model.ImageI(id, False)
        header_type = MetadataControl.detect_headers(path,
                                                     keep_default_na=True)
        LOGGER.debug(f"Detected header types: {header_type}")
        ctx = ParsingContext(client, omero_object, file=path,
                             column_types=header_type, allow_nan=True,
                             table_name=table_name)
        table_id = ctx.parse()
        LOGGER.info('Omero Metadata Table uploaded')
        return table_id
    except FileNotFoundError:
        LOGGER.error(f"File not found: {path}")
        raise
    except Exception as e:
        LOGGER.error(f"Error while uploading the table: {e}")
        raise


def compute_table_statistics(gateway, original_file_id, overwrite=False):
    """
    Compute table statistics and update table metadata in OMERO.

    :param gateway: An instance of a BlitzGateway object
    :param original_file_id: The ID of the OriginalFile for the table in OMERO
    """
    try:
        LOGGER.info("Starting table statistics compute.")
        gateway.SERVICE_OPTS.setOmeroGroup("-1")
        of = gateway.getObject("OriginalFile", original_file_id)

        resources = gateway.c.sf.sharedResources()
        table = resources.openTable(of._obj, _ctx={'omero.group': '-1'})
        columns = table.getHeaders()
        row_count = table.getNumberOfRows()
        bin_count = round(math.sqrt(row_count))

        LOGGER.debug(f"Number of columns: {len(columns)}, "
                     f"number of rows: {row_count}, "
                     f"number of bins: {bin_count}")

        ctx = {'omero.group': str(of.getDetails().getGroup().id)}
        for index, col in enumerate(columns):
            # Check if metadata exists
            existing_metadata = table.getAllMetadata(_ctx=ctx)
            if metadata_exists(existing_metadata, col.name) and not overwrite:
                LOGGER.info("Metadata already exists for column "
                            f"'{col.name}', skipping.")
                continue
            if (not isinstance(col, omero.grid.StringColumn) and
                    col.name != 'Roi' and col.name not in BOUNDS_LABELS):
                data = table.read([index], 0, row_count)
                df = pd.DataFrame(data.columns[0].values)
                table.setMetadata(f"{col.name}.min",
                                  omero.rtypes.rfloat(df[0].min()), _ctx=ctx)
                table.setMetadata(f"{col.name}.max",
                                  omero.rtypes.rfloat(df[0].max()), _ctx=ctx)
                table.setMetadata(f"{col.name}.mean",
                                  omero.rtypes.rfloat(df[0].mean()), _ctx=ctx)
                table.setMetadata(f"{col.name}.median",
                                  omero.rtypes.rfloat(df[0].median()),
                                  _ctx=ctx)
                table.setMetadata(f"{col.name}.std",
                                  omero.rtypes.rfloat(df[0].std()), _ctx=ctx)

                # If table is too small, skew and kurtosis will be NaN
                # convert NaN to "null" for json.dumps
                skew_val = df[0].skew()
                if pd.isna(skew_val):
                    table.setMetadata(f"{col.name}.skew",
                                      omero.rtypes.rstring("null"), _ctx=ctx)
                else:
                    table.setMetadata(f"{col.name}.skew",
                                      omero.rtypes.rfloat(skew_val), _ctx=ctx)

                kurt_val = df[0].kurtosis()
                if pd.isna(kurt_val):
                    table.setMetadata(f"{col.name}.kurtosis",
                                      omero.rtypes.rstring("null"), _ctx=ctx)
                else:
                    table.setMetadata(f"{col.name}.kurtosis",
                                      omero.rtypes.rfloat(kurt_val), _ctx=ctx)

                # Remove nan if present values as np.histogram breaks with nans
                data_without_nans = df[0].dropna()
                count, division = np.histogram(data_without_nans,
                                               bins=bin_count)
                count = list(count)
                count = [int(c) for c in count]
                table.setMetadata(f"{col.name}.histogram.count",
                                  omero.rtypes.rstring(json.dumps(count)),
                                  _ctx=ctx)
                table.setMetadata(f"{col.name}.histogram.division",
                                  omero.rtypes.rstring(
                                    json.dumps(list(division))
                                    ),
                                  _ctx=ctx)
                LOGGER.debug(f"Calculated metadata for column '{col.name}'")

            else:
                LOGGER.debug("Skipping metadata calculation for "
                             f"string column '{col.name}'")

    finally:
        # Close the table
        table.close()
    LOGGER.info("Finished table statistics compute.")


def link_table_to_roi(gateway, table_id, roi_id):
    """
    Link an OMERO.table to a ROI object

    :param gateway: An instance of a BlitzGateway object
    :param table_id: The ID of the OMERO.table
    :param roi_ID: The ID of the ROI to link the table to
    """

    query = (
        "select ann from FileAnnotation ann "
        "join fetch ann.file as f "
        "where f.id=:id"
    )
    params = omero.sys.ParametersI()
    params.addId(table_id)
    gateway.SERVICE_OPTS.setOmeroGroup("-1")
    file_ann = gateway.getQueryService().projection(
        query, params, gateway.SERVICE_OPTS)[0][0].val

    link = omero.model.RoiAnnotationLinkI()
    link.parent = omero.model.RoiI(roi_id, False)
    link.child = omero.model.FileAnnotationI(file_ann.id.val, False)
    ctx = {'omero.group': str(file_ann.getDetails().getGroup().getId().val)}
    gateway.getUpdateService().saveObject(link, ctx)
    LOGGER.info(f"Linked table {table_id} to ROI {roi_id}.")


def metadata_exists(existing_metadata, col_name):
    for key in existing_metadata.keys():
        if col_name in key:
            return True
    return False


def convert_ngff(args):
    """
    Inplace conversion of OME-NGFF image to label image.

    :param args: dictionary of input arguments
    :return: string of absolute path to the label image
    """
    ngff_file = args['input_file']
    no_fill = args['no_fill']
    if args['label'] is None:
        UUID = str(uuid.uuid4())
    else:
        UUID = args['label']
    overwrite = args.get('overwrite', False)

    series_store = zarr.storage.FSStore(
        ngff_file, auto_mkdir=True, mode='a',
        dimension_separator='/')
    series_group = zarr.group(series_store, overwrite=False)

    # check shape of input array
    array = series_group['0']
    shape = array.shape
    if any(i > 1 for i in [shape[0], shape[1], shape[2]]):
        raise Exception('Label images must be flat, greyscale XY planes.')

    # find num_objects
    if args['num_objects'] is None:
        LOGGER.warning(
            'Detecting object count from OME-NGFF input is inaccurate.'
        )
        # loop through resolution levels to calculate num_objects
        # exit loop at largest acceptable image
        num_objects = None
        for k in sorted(series_group.array_keys()):
            shape = series_group[k].shape
            if shape[3] < 4096 and shape[4] < 4096:
                num_objects = int(np.max(
                    series_group[k][0, 0, 0, :, :]
                ))
                break
        if num_objects is None:
            raise Exception("Must specify --num_objects when the smallest "
                            "resolution level is 4096x4096 or larger.")
    else:
        num_objects = int(args['num_objects'])

    # copy group data
    labels_path = os.path.join(ngff_file, 'labels')
    labels_store = zarr.storage.FSStore(
        labels_path, auto_mkdir=True, mode='a',
        dimension_separator='/')
    uuid_path = os.path.join(labels_path, UUID)
    if os.path.exists(uuid_path) and not overwrite:
        raise ValueError(f"Label with name {UUID} already exists in target")
    uuid_store = zarr.storage.FSStore(
        uuid_path, auto_mkdir=True, mode='a',
        dimension_separator='/')
    zarr.copy_store(series_store, uuid_store)

    # add labels metadata
    labels_group = zarr.group(labels_store, overwrite=False)
    if 'labels' in labels_group.attrs:
        UUIDs = labels_group.attrs['labels']
        UUIDs.append(UUID)
        labels_group.attrs['labels'] = UUIDs
    else:
        labels_group.attrs['labels'] = [UUID]

    # delete original arrays and metadata
    if not args['no_clean']:
        for k in series_group.array_keys():
            del series_group[k]
        series_group.attrs.put({})

    if no_fill:
        LOGGER.warning('No fill is not an option with OME-NGFF input.')

    with zarr.open_group(uuid_store) as A:
        label_attributes(A, max_object=num_objects, min_object=0)
    return uuid_path


def parse_file(args, input_file, file_extension):
    """
    Converts csv, wkt, or xml input file to a label image

    :param args: dictionary of input arguments
    :param input_file: csv, wkt, or xml input file
    :param file_extension: string for the extension of the input file
    :return: list of paths to label images, list of shape objects, nongeometry
    columns of object ids, data, etc
    """
    uuid_paths = []
    shape_lists = []
    extra_cols = None
    if file_extension == '.csv':
        with open(input_file, newline='') as csvfile:
            reader = csv.reader(csvfile, delimiter='\n', quotechar='|')
            for row in reader:
                if row[0].startswith('#'):
                    # Skip '# header' row as it's automatically detected in
                    # omero-metadata >0.11.0
                    LOGGER.warning(
                        'Ignoring "# header" row. ' +
                        'Please run omero metadata manually with the ' +
                        'relevant CLI arguments to enable the manual ' +
                        'header definition (see ' +
                        'github.com/ome/omero-metadata for more details).')
                    shapes = pd.read_csv(input_file, skiprows=1)
                else:
                    shapes = pd.read_csv(input_file)
                break
        if args['column_name'] not in shapes.columns:
            raise Exception("No polygon column in CSV input.")
        if 'object' not in shapes.columns:
            raise Exception("No object column in CSV input.")

        column = args['column_name']
        if args['register_to'] is not None:
            extra_cols = shapes.loc[:, shapes.columns != column]
            if INDEX_COLUMN in extra_cols.columns:
                pass
            elif 'id' in extra_cols.columns:
                extra_cols.rename(columns={'id': INDEX_COLUMN}, inplace=True)
            else:
                extra_cols[INDEX_COLUMN] = extra_cols.index + 1
            extra_cols.set_index(INDEX_COLUMN, inplace=True)
        shapes = list(shapes[column].map(wkt.loads))

        shape_lists.append(shapes)

    elif file_extension == '.wkt':
        with open(input_file) as file:
            collections = file.readlines()
            for collection in collections:
                LOGGER.info('parsing collection %s of %s' % (
                    collections.index(collection) + 1, len(collections)))
                shapes = list(wkt.loads(collection))
                shape_lists.append(shapes)

    elif file_extension == '.xml':
        LOGGER.debug("Scanning XML file")
        from lxml import etree
        shapes = []
        idx = 0
        context = etree.iterparse(input_file, tag="{*}ROI")
        for action, node in context:
            idx += 1
            roi_data = node[0][0]
            roi_type = roi_data.tag.rpartition("}")[-1]
            roi_dict = roi_data.attrib
            if roi_type == 'Polygon':
                coords = [tuple(map(float, s.split(','))) for s in
                          roi_dict['Points'].split(' ')]
                shapes.append(Polygon(coords))
            elif roi_type == 'Ellipse':
                x = float(roi_dict['X'])
                y = float(roi_dict['Y'])
                sx = float(roi_dict['RadiusX'])
                sy = float(roi_dict['RadiusY'])
                circle = Point(x, y).buffer(1)
                ellipse = scale(circle, sx, sy)
                transform_matrix = get_transform_matrix(roi_data)
                if transform_matrix != AFFINE_MATRIX:
                    # No need to transform if matrix applies no transform.
                    ellipse = affine_transform(ellipse, transform_matrix)
                shapes.append(ellipse)
            elif roi_type == 'Rectangle':
                x = float(roi_dict['X'])
                y = float(roi_dict['Y'])
                w = float(roi_dict['Width'])
                h = float(roi_dict['Height'])
                rect = Polygon([(x, y), (x + w, y), (x + w, y + h),
                                (x, y + h), (x, y)])
                transform_matrix = get_transform_matrix(roi_data)
                if transform_matrix != AFFINE_MATRIX:
                    # No need to transform if matrix applies no transform.
                    rect = affine_transform(rect, transform_matrix)
                shapes.append(rect)
            else:
                LOGGER.info(f"Unsupported shape {roi_type} was not converted")
            node.clear()
            for ancestor in node.xpath('ancestor-or-self::*'):
                while ancestor.getprevious() is not None:
                    del ancestor.getparent()[0]
            if idx % 100000 == 0:
                LOGGER.debug(f"Loaded {idx} ROIs")
                # break
        del context
        num_shapes = len(shapes)

        if shapes:
            LOGGER.info(f'Found {num_shapes} compatible ROIs.')
        else:
            LOGGER.info("No ROI objects found, are you using a "
                        "compatible OME-XML version?")
        shape_lists.append(shapes)

    else:
        raise NotImplementedError("Unsupported file type")
    offset = 1
    label = args.get('label', None)
    for idx, shapes in enumerate(shape_lists):
        if label is not None:
            if len(shape_lists) > 1:
                UUID = f"{label}_{idx}"
            else:
                UUID = label
        else:
            UUID = str(uuid.uuid4())
        shapes = geopandas.GeoSeries(shapes)
        if extra_cols is not None and extra_cols.index.name == INDEX_COLUMN:
            shapes.index = extra_cols.index
        else:
            shapes.index += offset
            offset += len(shapes)
        data_type = max_index_to_dtype(shapes.index.max())
        uuid_path = raster_shapes(shapes, args, UUID, data_type)
        uuid_paths.append(uuid_path)

    return uuid_paths, shape_lists, extra_cols


def max_index_to_dtype(max_index):
    if max_index > np.iinfo(np.uint8).max:
        if max_index > np.iinfo(np.uint16).max:
            data_type = np.uint32
        else:
            data_type = np.uint16
    else:
        data_type = np.uint8
    return data_type


def raster_shapes(shapes, args, UUID, data_type=None):
    num_procs = min(args['max_procs'], len(shapes))
    mode = args['mode']
    width = int(args['width'])
    height = int(args['height'])
    out_dir = args['directory']
    out_filename = args['output_filename']

    num_shapes = len(shapes)
    if data_type is None:
        data_type = max_index_to_dtype(num_shapes)
    LOGGER.debug(f'Data type set to {data_type}')
    directory, base, resolution_levels = makezarr(
        out_dir, out_filename, image=False, label=True,
        metadata='', UUID=UUID,
        shape=(1, 1, 1, height, width),
        data_type=data_type, series=args['series'],
        overwrite=args.get('overwrite', False), debug=args['debug'])

    # MP pool may need to start in spawn mode to avoid issues with OMERO.py
    ctx = mp.get_context('spawn')
    # Start pool now to fork before we do anything memory intensive.
    pool = ctx.Pool(processes=num_procs)
    if not isinstance(shapes, geopandas.GeoSeries):
        geodata = geopandas.GeoSeries(shapes)
    else:
        geodata = shapes
    sql_path = ""
    if mode == "postgres":
        db = args['db']
        generate_postgres(geodata, db)
        geodata = None
    elif mode == "sqlite":
        sql_path = generate_sql(geodata)
        geodata = None
    tile_size = int(args['tile_size'])
    tile_x = math.ceil(width / tile_size)
    tile_y = math.ceil(height / tile_size)

    man = mp.Manager()

    jobs = man.Queue()
    for x in range(tile_x):
        for y in range(tile_y):
            jobs.put((x, y))
    LOGGER.info(f"Starting raster workers to process {jobs.qsize()} tiles")
    sync = zarr.ProcessSynchronizer(path=tempfile.gettempdir())
    for wn in range(num_procs):
        pool.apply_async(worker, (jobs, geodata, args, resolution_levels,
                                  directory, wn + 1, data_type, sync,
                                  mode, sql_path))
    pool.close()
    LOGGER.debug("Waiting for workers to finish")
    pool.join()
    LOGGER.info("All workers finished.")
    if sql_path:
        # For now, we delete the spatial database after use.
        # We may want to store this properly in the future.
        try:
            os.remove(sql_path)
            LOGGER.info("Temporary database deleted")
        except OSError:
            LOGGER.warning("Unable to delete database at ", sql_path)

    # Annotate the zarr with some metadata
    with zarr.open_group(directory) as A:
        label_attributes(A, max_object=num_shapes, min_object=0)
    return directory


def worker(queue, geoseries, args, levels, directory, workerid,
           data_type=np.int32, sync=None, mode='sqlite', sqlpath=''):
    # We don't want to have to load the geopandas array for every job.
    # We use this function to distribute work once it's loaded onto a process.
    pname = f"RasterWorker-{workerid}"
    mp.current_process().name = pname
    LOGGER.info(f"{pname}: Data loaded, starting jobs...")
    errors = 0
    if mode == 'postgres':
        LOGGER.debug(f"{pname}: In postgres mode...")
        engine = create_engine(args['db'])
    elif mode == "sqlite":
        LOGGER.debug(f"{pname}: In sql mode...")
        engine = sqlite3.connect(sqlpath)
        engine.enable_load_extension(True)
        engine.load_extension("mod_spatialite")
    else:
        LOGGER.debug(f"{pname}: In local mode...")
        engine = None
    while not queue.empty():
        x, y = queue.get()
        try:
            raster_multiprocess(x, y, geoseries, args, levels, directory,
                                pname, data_type=data_type, sync=sync,
                                engine=engine, mode=mode)
        except Exception as e:
            # Abandon work if jobs repeatedly fail.
            LOGGER.error(f"{pname}: Error on tile {x}, {y}: {e}")
            if errors < 5:
                errors += 1
                queue.put((x, y))
            else:
                LOGGER.error(f"{pname}: Abandoning job {x}, {y}")
    if engine:
        engine.close()
    LOGGER.info(f"{pname}: Queue empty, shutting down.")


def get_transform_matrix(roi_data):
    if not roi_data.getchildren():
        return AFFINE_MATRIX
    transform_dict = roi_data[0].attrib
    a = float(transform_dict['A00'])
    b = float(transform_dict['A01'])
    d = float(transform_dict['A10'])
    e = float(transform_dict['A11'])
    xoff = float(transform_dict['A02'])
    yoff = float(transform_dict['A12'])
    return a, b, d, e, xoff, yoff


def generate_postgres(geoseries, dest):
    df = geopandas.GeoDataFrame({'id': geoseries.index},
                                index=geoseries.index,
                                geometry=geoseries)
    engine = create_engine(dest)
    engine.execute("DROP TABLE IF EXISTS polygons;")
    LOGGER.info("Sending data to postgres database")
    df.to_postgis(name="polygons", con=engine, schema='public')


def generate_sql(geoseries):
    LOGGER.info("Generating SQLite database")
    temp_dir = tempfile.gettempdir()
    db_path = os.path.join(temp_dir, f"geodata_{uuid.uuid4()}.db")
    df = pd.DataFrame(data=geoseries.index, columns=['id'])
    # Create the table and populate it with non-geospatial datatypes
    wkts = geoseries.to_wkt().tolist()
    with sqlite3.connect(db_path) as conn:
        conn.enable_load_extension(True)
        conn.load_extension("mod_spatialite")
        df.to_sql('features', conn, if_exists='replace', index=True)
        conn.execute("SELECT InitSpatialMetaData(1);")

        conn.execute("SELECT AddGeometryColumn('features', 'polygons', "
                     "4326, 'POLYGON', 2);")

        LOGGER.info("Sending polygons to database")

        query = "INSERT INTO features ('id', 'polygons') VALUES " \
                "(?, GeomFromText(?, 4326));"

        conn.executemany(query, enumerate(wkts))

        LOGGER.debug("Data loaded into database")
        # Generate exportable blob column now rather than doing it on the fly.
        conn.execute("ALTER TABLE features ADD COLUMN blob BLOB;")
        conn.execute("UPDATE features SET blob = ST_AsBinary(polygons)")

        conn.execute("SELECT CreateSpatialIndex('features', 'polygons')")
        LOGGER.info("Completed spatial indexing")
        conn.commit()
    return db_path


def raster_multiprocess(x, y, geoseries, args, resolutions, directory, pname,
                        data_type=np.int32, sync=None, engine=None,
                        mode="sqlite"):
    no_fill = args['no_fill']
    tile_width = tile_height = tile_size = args['tile_size']
    x1 = x * tile_width
    x2 = x1 + tile_width
    y1 = y * tile_height
    y2 = y1 + tile_height

    if x2 > args['width']:
        x2 = args['width']
        tile_width = x2 - x1
    if y2 > args['height']:
        y2 = args['height']
        tile_height = y2 - y1

    border = Polygon([(x1, y1), (x2, y1), (x2, y2), (x1, y2)])
    # Fetch geoseries from database
    if mode == "postgres":
        # Postgres query
        query = \
            f"""
            select id, polygons.geometry as geom from polygons
            where st_intersects(geometry, ST_GeomFromText('{border.wkt}', 0))
            """
        intersections = geopandas.read_postgis(query, engine)
        to_raster = intersections['geom'].tolist()
        values = (intersections['id'].astype(int)).tolist()
    elif mode == "sqlite":
        query = \
            f"select id, blob as geom from features WHERE ROWID in " \
            f"(SELECT ROWID FROM SpatialIndex WHERE " \
            f"f_table_name = 'features' and " \
            f"search_frame = GeomFromText('{border.wkt}', 1));"
        intersections = geopandas.read_postgis(query, engine, crs=4326)
        to_raster = intersections['geom'].tolist()
        values = (intersections['id'].astype(int)).tolist()
    else:
        # Using geoseries sent to worker processes
        intersections = geoseries.intersects(border)
        LOGGER.debug(f"{pname}: Tile {x}, {y} - Got intersections")
        to_raster = geoseries[intersections].tolist()
        values = geoseries[intersections].index.tolist()
    to_raster = [
        translate(
            geom, xoff=-(x * tile_size), yoff=-(y * tile_size)
        ) for geom in to_raster]
    LOGGER.debug(f"{pname}: Tile {x}, {y} - "
                 f"Will raster {len(to_raster)} objects")
    if len(to_raster) > 0:
        for res in range(resolutions):
            factor = 2
            path = os.path.join(directory, str(res))
            if res == 0:
                w = tile_width
                h = tile_height
                x_loc = x * tile_size
                y_loc = y * tile_size
                rastered_data = features.rasterize(
                    [(
                        geom.exterior if no_fill else geom, val
                    ) for geom, val in zip(
                        to_raster, values)],
                    (h, w)).astype(data_type)
            else:
                x_loc = x_loc // factor
                y_loc = y_loc // factor
                w = w // factor
                h = h // factor
                if h > 0 and w > 0:
                    if args['downsample_type'] == 'vector':
                        to_raster_scaled = []
                        for obj, val in zip(to_raster, values):
                            center = obj.centroid.coords.xy
                            to_raster_scaled.append(
                                scale(
                                    translate(
                                        obj,
                                        xoff=-center[0][0] // factor,
                                        yoff=-center[1][0] // factor),
                                    xfact=(1 / factor),
                                    yfact=(1 / factor),
                                    origin='centroid'))
                        to_raster = to_raster_scaled
                        rastered_data = features.rasterize(
                            [(
                                geom.exterior if no_fill else geom, val
                            ) for geom, val in zip(
                                to_raster, values)],
                            (h, w)).astype(data_type)
                    else:
                        rastered_data = cv2.resize(
                            rastered_data.astype(np.float32)
                            if data_type is np.uint32 else rastered_data,
                            dsize=(w, h),
                            interpolation=cv2.INTER_NEAREST
                        ).astype(data_type)
                else:
                    break
            writezarr(rastered_data, x_loc, y_loc, w, h, path,
                      scaling=False, sync=sync)
    else:
        LOGGER.debug(f"{pname}: Tile {x}, {y} had no objects")
    LOGGER.info(f'{pname}: Completed tile {x}, {y} with {len(to_raster)} ROIs')


def register(
        gateway, image_id, uuid_paths, args):
    """
    Function to create and register roi/s in omero with correct reference
    (lsid) to the location of the label image

    :param image_id: omero image ID
    :param uuid_paths: list of absolute paths to the label image
    :param args: dictionary of input arguments
    :return: roi object, roi name, and roi id in omero
    """
    roi_name = args['name']
    if type(uuid_paths) is not list:
        uuid_paths = list(uuid_paths)
    image = omero.model.ImageI(image_id, False)
    rois = []
    img = gateway.getObject("Image", image_id)
    ctx = {'omero.group': str(img.getDetails().getGroup().getId())}
    for uuid_path in uuid_paths:
        uuid_path = os.path.abspath(uuid_path)
        uuid = os.path.basename(uuid_path)
        if args['server_directory']:
            LOGGER.debug('Registering to server directory: ' +
                         f'{args["server_directory"]}')
            # Use server directory path defined by the user instead
            path_comp = uuid_path.split(os.sep)
            uuid_path = "/".join((args['server_directory'].rstrip('/'),
                                  *path_comp[-4:]))
        else:
            LOGGER.warn('No server directory specified. ' +
                        f'Using "{uuid_path}" for registration')
        roi_el = omero.model.RoiI()
        roi_el.setName(rstring(roi_name))
        roi_el
        mask = omero.model.MaskI()
        mask.setTextValue(rstring(roi_name))
        mask.setTheC(rint(0))
        mask.setTheZ(rint(0))
        mask.setTheT(rint(0))
        mask.setX(rdouble(0))
        mask.setY(rdouble(0))
        mask.setWidth(rdouble(img.getSizeX()))
        mask.setHeight(rdouble(img.getSizeY()))
        mask_color = ColorHolder()
        mask_color.setRed(255)
        mask_color.setBlue(0)
        mask_color.setGreen(255)
        mask_color.setAlpha(100)
        mask.setFillColor(rint(mask_color.getInt()))
        mask.details.externalInfo = omero.model.ExternalInfoI()
        mask.details.externalInfo.entityType = rstring(
            'com.glencoesoftware.ngff:multiscales'
        )
        mask.details.externalInfo.entityId = rlong(3)
        mask.details.externalInfo.uuid = omero.rtypes.rstring(uuid)
        mask.details.externalInfo.lsid = omero.rtypes.rstring(uuid_path)
        roi_el.addShape(mask)
        roi_el.setImage(image)
        rois.append(roi_el)
    rois = gateway.getUpdateService().saveAndReturnArray(rois, ctx)
    roi_id = rois[0].getId().val
    LOGGER.info(f'Registered label image at {uuid_path}')
    LOGGER.info("Added ROI %s" % roi_id)
    return rois, roi_name, roi_id


def get_omero_client(args):
    LOGGER.debug("Connecting to OMERO server")
    session_key = args.get('key', None)
    server = args.get('server', None)
    user = args.get("user", None)
    password = args.get("password", None)
    port = int(args.get("port", 4064))
    if server is None and user is None is None and session_key is None:
        # Try omero_user_token instead
        try:
            import omero_user_token
            LOGGER.info("Requesting token info")
            token = omero_user_token.getter()
            server, port = token[token.find('@') + 1:].split(':')
            port = int(port)
            LOGGER.info("Connection to {}:{}".format(server, port))
            session_key = token[:token.find('@')]
        except Exception:
            LOGGER.error("Unable to get OMERO user token", exc_info=True)
    if server is None:
        LOGGER.error("Can't connect with no server details")
        raise Exception("No connection specified for OMERO registration.")
    client = None
    try:
        if session_key is not None:
            client = omero.client(host=server, port=port)
            session = client.joinSession(session_key)
            client.enableKeepAlive(60)
            session.detachOnDestroy()
        elif user is not None and password is not None:
            client = omero.client(host=server, port=port)
            session = client.createSession(username=user, password=password)
            client.enableKeepAlive(60)
            session.detachOnDestroy()
            session_key = client.getSessionId()
        else:
            raise ValueError("Insufficient parameters to create OMERO "
                             "connection")
    except Exception:
        if client is not None:
            client.__del__()
        raise
    return client, server, session_key


def check_running_on_windows():
    """
    Checks if this script is running on Windows, directly or via cygwin.
    """
    return sys.platform.startswith(('win32', 'cygwin'))


def check_abspath_server_dir(path):
    """
    Checks if path is absolute. Raises TypeError if not.

    :param path: string path
    :return: string path
    """
    if path.startswith("/"):
        if posixpath.isabs(path):
            return path
        else:
            raise argparse.ArgumentTypeError(f"'{path}' is not an " +
                                             "absolute path.")
    elif path.startswith("s3://"):
        return path
    else:
        raise argparse.ArgumentTypeError(f"'{path}' is not a " +
                                         "valid path.")


def main():
    parse_arguments()


if __name__ == "__main__":
    main()
